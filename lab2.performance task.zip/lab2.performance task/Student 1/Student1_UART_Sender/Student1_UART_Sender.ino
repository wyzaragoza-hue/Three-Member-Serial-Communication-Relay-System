/*
  ============================================================
  Laboratory 2 Performance Task
  Three-Member Serial Communication Relay System
  ------------------------------------------------------------
  STUDENT 1 - UART SENDER
  ------------------------------------------------------------
  Responsibility:
    - Read a sentence typed into the USB Serial Monitor
    - Transmit that sentence to Student 2 over UART2
    - Append '\n' as the End-Of-Message (EOM) marker so
      Student 2 / Student 3 know where the message ends

  Hardware connections (Student 1 -> Student 2):
    ESP32 (Student 1) GPIO17 (TX2) -> ESP32 (Student 2) GPIO16 (RX2)
    ESP32 (Student 1) GND          -> ESP32 (Student 2) GND
  ============================================================
*/

#define UART_BAUD     115200
#define UART2_TX_PIN  17     // TX -> Student 2 RX
#define UART2_RX_PIN  16     // not used for sending, defined for completeness

HardwareSerial UART2(2);     // ESP32 has UART0, UART1, UART2 -> use UART2

void setup() {
  Serial.begin(115200);                                    // USB Serial Monitor
  UART2.begin(UART_BAUD, SERIAL_8N1, UART2_RX_PIN, UART2_TX_PIN);

  Serial.println("========================================");
  Serial.println(" STUDENT 1 - UART SENDER READY");
  Serial.println(" Type a sentence in the Serial Monitor");
  Serial.println(" and press ENTER to transmit it.");
  Serial.println("========================================");
}

void loop() {
  if (Serial.available()) {
    String sentence = Serial.readStringUntil('\n');
    sentence.trim();                    // strip trailing '\r' / stray spaces

    if (sentence.length() > 0) {
      // Transmit the sentence through UART2, '\n' marks end of message
      UART2.print(sentence);
      UART2.print('\n');

      Serial.print("[SENT via UART]  -> \"");
      Serial.print(sentence);
      Serial.println("\"");
    }
  }
}
