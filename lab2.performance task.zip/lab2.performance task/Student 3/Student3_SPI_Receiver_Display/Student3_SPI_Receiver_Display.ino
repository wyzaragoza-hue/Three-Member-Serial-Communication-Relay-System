/*
  ============================================================
  Laboratory 2 Performance Task
  Three-Member Serial Communication Relay System
  ------------------------------------------------------------
  STUDENT 3 - SPI RECEIVER / DISPLAY  (SPI SLAVE)
  ------------------------------------------------------------
  Responsibility:
    - Act as the SPI slave (Student 2 is the SPI master)
    - Receive bytes over SPI (MOSI, SCLK, CS driven by Student 2)
    - Reconstruct the sentence, using '\n' as the end-of-message
      marker
    - Print the completed sentence on its own Serial Monitor

  Hardware connections (Student 2 -> Student 3, VSPI bus):
      SCLK  GPIO18 -> GPIO18
      MOSI  GPIO23 -> GPIO23
      MISO  GPIO19 -> GPIO19
      CS/SS GPIO5  -> GPIO5
      GND          -> GND

  NOTE:
    The Arduino "SPI" library only implements SPI MASTER mode.
    ESP32 SPI SLAVE mode must use the ESP-IDF driver
    (driver/spi_slave.h), which is available in the Arduino-ESP32
    core. If your installed core version does not expose this
    driver cleanly, the alternative is to install the
    "ESP32SPISlave" library (by hideakitai) from the Library
    Manager, which wraps the same driver with a simpler API.
    Verify against your specific board/core version before the
    final demonstration, as stated in the lab instructions.
  ============================================================
*/

#include "driver/spi_slave.h"

#define SPI_HOST_USED   VSPI_HOST
#define PIN_MOSI        23
#define PIN_MISO        19
#define PIN_SCLK        18
#define PIN_CS           5

#define BUF_SIZE        128

WORD_ALIGNED_ATTR uint8_t rx_buffer[BUF_SIZE];
WORD_ALIGNED_ATTR uint8_t tx_buffer[BUF_SIZE];

String message = "";

void setup() {
  Serial.begin(115200);
  delay(300);

  Serial.println("========================================");
  Serial.println(" STUDENT 3 - SPI RECEIVER / DISPLAY READY");
  Serial.println(" (SPI SLAVE)");
  Serial.println("========================================");

  gpio_set_pull_mode((gpio_num_t)PIN_MOSI, GPIO_PULLUP_ONLY);
  gpio_set_pull_mode((gpio_num_t)PIN_SCLK, GPIO_PULLUP_ONLY);
  gpio_set_pull_mode((gpio_num_t)PIN_CS,   GPIO_PULLUP_ONLY);

  spi_bus_config_t buscfg = {};
  buscfg.mosi_io_num = PIN_MOSI;
  buscfg.miso_io_num = PIN_MISO;
  buscfg.sclk_io_num = PIN_SCLK;
  buscfg.quadwp_io_num = -1;
  buscfg.quadhd_io_num = -1;

  spi_slave_interface_config_t slvcfg = {};
  slvcfg.spics_io_num = PIN_CS;
  slvcfg.flags = 0;
  slvcfg.queue_size = 3;
  slvcfg.mode = 0;

  esp_err_t ret = spi_slave_initialize(SPI_HOST_USED, &buscfg, &slvcfg, SPI_DMA_CH_AUTO);
  if (ret != ESP_OK) {
    Serial.println("!! SPI slave initialization FAILED !!");
  }
}

void loop() {
  memset(rx_buffer, 0, BUF_SIZE);
  memset(tx_buffer, 0, BUF_SIZE);

  spi_slave_transaction_t t = {};
  t.length    = BUF_SIZE * 8;     // max bits for this transaction window
  t.tx_buffer = tx_buffer;
  t.rx_buffer = rx_buffer;

  // Blocks until Student 2 (master) performs one CS-low transaction
  esp_err_t ret = spi_slave_transmit(SPI_HOST_USED, &t, portMAX_DELAY);

  if (ret == ESP_OK) {
    for (int i = 0; i < BUF_SIZE; i++) {
      char c = (char)rx_buffer[i];
      if (c == 0) continue;              // padding / unused bytes

      if (c == '\n') {
        Serial.print("[FINAL MESSAGE] -> \"");
        Serial.print(message);
        Serial.println("\"");
        message = "";                    // ready for next sentence
      } else {
        message += c;
      }
    }
  }
}
