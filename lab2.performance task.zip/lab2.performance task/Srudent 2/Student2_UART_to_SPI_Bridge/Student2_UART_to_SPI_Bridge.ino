/*
  ============================================================
  Laboratory 2 Performance Task
  Three-Member Serial Communication Relay System
  ------------------------------------------------------------
  STUDENT 2 - UART -> SPI BRIDGE  (SPI MASTER)
  ------------------------------------------------------------
  Responsibility:
    - Receive characters from Student 1 over UART2
    - Buffer the characters until '\n' (end-of-message marker)
    - Re-transmit the completed sentence to Student 3 using SPI
      (Student 2 = SPI master, Student 3 = SPI slave)

  Hardware connections:
    Student 1 -> Student 2 (UART):
      Student 1 TX (GPIO17) -> Student 2 RX2 (GPIO16)
      GND                    -> GND

    Student 2 -> Student 3 (SPI, VSPI bus):
      SCLK  GPIO18 -> GPIO18
      MOSI  GPIO23 -> GPIO23
      MISO  GPIO19 -> GPIO19
      CS/SS GPIO5  -> GPIO5
      GND          -> GND
  ============================================================
*/

#include <SPI.h>

#define UART_BAUD     115200
#define UART2_RX_PIN  16      // <- Student 1 TX
#define UART2_TX_PIN  17      // not used for this stage

#define SPI_SCLK_PIN  18
#define SPI_MISO_PIN  19
#define SPI_MOSI_PIN  23
#define SPI_CS_PIN     5

HardwareSerial UART2(2);
String buffer = "";

void setup() {
  Serial.begin(115200);
  UART2.begin(UART_BAUD, SERIAL_8N1, UART2_RX_PIN, UART2_TX_PIN);

  pinMode(SPI_CS_PIN, OUTPUT);
  digitalWrite(SPI_CS_PIN, HIGH);        // idle = slave not selected

  SPI.begin(SPI_SCLK_PIN, SPI_MISO_PIN, SPI_MOSI_PIN, SPI_CS_PIN);

  Serial.println("========================================");
  Serial.println(" STUDENT 2 - UART TO SPI BRIDGE READY");
  Serial.println(" (SPI MASTER)");
  Serial.println("========================================");
}

void loop() {
  while (UART2.available()) {
    char c = UART2.read();
    buffer += c;

    if (c == '\n') {
      Serial.print("[UART RECEIVED] -> \"");
      Serial.print(buffer);
      Serial.println("\"");

      sendOverSPI(buffer);
      buffer = "";                       // reset for next message
    }
  }
}

void sendOverSPI(String msg) {
  SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));

  digitalWrite(SPI_CS_PIN, LOW);         // select Student 3 (slave)
  delayMicroseconds(50);                 // give the slave time to arm its transaction

  for (unsigned int i = 0; i < msg.length(); i++) {
    SPI.transfer((uint8_t)msg[i]);
    delayMicroseconds(200);              // pace bytes so slave ISR can keep up
  }

  digitalWrite(SPI_CS_PIN, HIGH);        // deselect -> ends this SPI transaction
  SPI.endTransaction();

  Serial.print("[SENT via SPI]   -> \"");
  Serial.print(msg);
  Serial.println("\"");
}
